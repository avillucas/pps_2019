export class Friend {
  username: string = '';
  fullname: string = '';
  avatar: string = '';
  email: string = '';
}

export class User {
  username: string = '';
  password: string = '';
  fullname: string = '';
  avatar: string = '';
  email: string = '';
}
